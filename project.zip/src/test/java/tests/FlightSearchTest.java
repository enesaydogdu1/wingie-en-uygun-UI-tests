package tests;

import base.BaseTest;
import io.qameta.allure.*;
import org.testng.annotations.*;
import pages.HomePage;
import pages.ResultsPage;
import utils.AssertionsHelper;
import utils.ConfigReader;

import java.util.List;

@Epic("Flight Search")
@Feature("Round Trip + Time Filter")
@Owner("Enes")                  // Allure owner
public class FlightSearchTest extends BaseTest {

    @Severity(SeverityLevel.CRITICAL)
    @Story("Case 1: Temel Uçuş Arama ve Saat Filtresi")
    @TmsLink("TMS-1001")         // test case id (TMS/Zephyr/TestOps vs.)
    @Issue("BUG-1234")           // bilinen bug varsa
    @Link(name = "Spec", type = "doc", url = "https://your.wiki/specs/flight-search")
    @Description("""
        İstanbul - Ankara gidiş-dönüş araması yapılır.
        Kalkış saati filtresi 10:00–18:00 uygulanır.
        Sonuç kartlarından kalkış saat/tarih/şehir doğrulanır.
        """)
    @Test(description = "İstanbul - Ankara gidiş-dönüş + 10:00–18:00 kalkış filtresi")
    public void basicRoundTripWithTimeFilter(@Optional String baseUrl,
                                             @Optional String fromCity,
                                             @Optional String toCity,
                                             @Optional String departDate,
                                             @Optional String returnDate) {

        // ---- Parametreleri kaynaklardan topla
        String url = baseUrl != null ? baseUrl : ConfigReader.get("baseUrl");
        String from = fromCity != null ? fromCity : ConfigReader.get("fromCity");
        String to = toCity != null ? toCity : ConfigReader.get("toCity");
        String d1 = departDate != null ? departDate : ConfigReader.get("departDate");   // yyyy-MM-dd
        String d2 = returnDate != null ? returnDate : ConfigReader.get("returnDate");

        // ---- Allure'a parametreleri işle (raporda görünür)
        Allure.parameter("Base URL", url);
        Allure.parameter("From", from);
        Allure.parameter("To", to);
        Allure.parameter("Depart Date (yyyy-MM-dd)", d1);
        Allure.parameter("Return Date (yyyy-MM-dd)", d2);
        Allure.parameter("Time Filter", "10:00–18:00");

        // ---- Adımlar (Page Object’lerde @Step zaten var; burada üst seviye step’ler)
        Allure.step("Ana sayfaya git & gidiş-dönüş ayarla & şehirler ve tarihleri seç & ara", () -> {
            new HomePage(driver, explicitWaitSec)
                    .goTo(url)
                    .ensureRoundTrip()
                    .setFrom(from)
                    .setTo(to)
                    .setDates(d1, d2)
                    .search();
        });

        ResultsPage results = Allure.step("Sonuçları bekle & kalkış saati filtresi uygula (10:00–18:00)", () ->
                new ResultsPage(driver, explicitWaitSec)
                        .waitForResults()
                        .applyDepartureTimeFilter("10:00", "18:00")
        );

        List<String> kalkisSaatleri = Allure.step("Kartlardan kalkış saatlerini topla", results::karttakiKalkisSaatleriniGetir
        );

        List<String> kalkisTarihleri = Allure.step("Kartlardan kalkış tarihlerini topla", results::karttakiKalkisTarihlereniGetir
        );

        List<String> kalkisSehirleri = Allure.step("Kartlardan kalkış şehirlerini topla", results::karttakiKalkisSehirleriniGetir
        );

        // ---- Assertions (helper’lar Allure log basıyor)
        Allure.step("Saatlerin 10:00–18:00 aralığında olduğunu doğrula", () ->
                AssertionsHelper.assertTimesWithinRange(kalkisSaatleri, "10:00", "18:00")
        );

        Allure.step("Kalkış tarihlerinin departDate ile eşit olduğunu doğrula", () ->
                AssertionsHelper.assertDatesEqual(kalkisTarihleri, d1)
        );

        Allure.step("Kalkış şehirlerinin 'from' ile eşit olduğunu doğrula", () ->
                AssertionsHelper.assertCitiesEqual(kalkisSehirleri, from)
        );
    }


}
