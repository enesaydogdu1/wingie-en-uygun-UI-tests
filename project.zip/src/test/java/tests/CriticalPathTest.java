package tests;

import base.BaseTest;
import io.qameta.allure.*;
import org.openqa.selenium.By;
import org.testng.annotations.*;
import pages.HomePage;
import pages.PassengerFormPage;
import pages.ResultsPage;
import utils.AssertionsHelper;
import utils.ConfigReader;

@Epic("Critical Path")
@Feature("Kritik Kullanıcı Yolculuğu")
@Owner("Enes")
public class CriticalPathTest extends BaseTest {

    // Basit kritik yol: arama -> sonuç -> ilk gidiş + dönüş seç -> yolcu bilgileri sayfasına kadar ilerle
    private final By selectFlight = By.xpath("//*[@id=\"flight-0\"]/div[1]");
    private final By selectAndContinueButton = By.cssSelector("button[data-testid='providerSelectBtn']");
    private final By firstReturnFlightCard = By.cssSelector("div.flight-list.flight-list-return.domesticList div.flight-item__wrapper:first-of-type");
    private final By superEkoPackage = By.xpath("//*[@id=\"flight-0\"]/div[1]/div[6]/div/div[1]");

    private final By passengerForm = By.xpath("//*[@id=\"passenger-form\"]");
    private final By paymentForm = By.xpath("//*[@id=\"payment-form\"]");

    @Severity(SeverityLevel.BLOCKER)
    @Story("Durum 3: Kritik Yol Testi")
    @TmsLink("TMS-1003")
    @Issue("BUG-3456")
    @Link(name = "Spec", type = "doc", url = "https://your.wiki/specs/critical-path")
    @Description("""
        Kullanıcının temel satın alma yolculuğu uçtan uca denenir:
        Arama -> Sonuç listesi -> İlk gidiş uçuşunu seç -> İlk dönüş uçuşunu seç -> Paket seç -> Yolcu formu -> Ödeme adımı görünürlüğü.
        Her adım Allure ile loglanır, parametreler rapora işlenir.
        """)
    @Test(description = "Kullanıcının temel satın alma yolculuğu kırılmadan çalışıyor mu?")
    @Parameters({"baseUrl", "fromCity", "toCity", "departDate", "returnDate"})
    public void criticalJourney(@Optional String baseUrl,
                                @Optional String fromCity,
                                @Optional String toCity,
                                @Optional String departDate,
                                @Optional String returnDate) throws InterruptedException {

        // ---- Parametreleri topla (boşsa ConfigReader)
        String url  = baseUrl   != null ? baseUrl   : ConfigReader.get("baseUrl");
        String from = fromCity  != null ? fromCity  : ConfigReader.get("fromCity");
        String to   = toCity    != null ? toCity    : ConfigReader.get("toCity");
        String d1   = departDate!= null ? departDate: ConfigReader.get("departDate");   // yyyy-MM-dd
        String d2   = returnDate!= null ? returnDate: ConfigReader.get("returnDate");

        // ---- Allure parametreleri (rapora düşsün)
        Allure.parameter("Base URL", url);
        Allure.parameter("From", from);
        Allure.parameter("To", to);
        Allure.parameter("Depart Date (yyyy-MM-dd)", d1);
        Allure.parameter("Return Date (yyyy-MM-dd)", d2);

        // ---- Adımlar
        Allure.step("Ana sayfaya git, gidiş-dönüş seç, şehir ve tarihleri gir, ara", () -> {
            new HomePage(driver, explicitWaitSec)
                    .goTo(url)
                    .ensureRoundTrip()
                    .setFrom(from)
                    .setTo(to)
                    .setDates(d1, d2)
                    .search();
        });

        Allure.step("Sonuç listesinin yüklenmesini bekle", () ->
                new ResultsPage(driver, explicitWaitSec).waitForResults()
        );

        Allure.step("İlk gidiş uçuş kartını seç", () ->
                driver.findElement(selectFlight).click()
        );

        Allure.step("Sağlayıcı seç ve devam et butonuna tıkla", () ->
                driver.findElement(selectAndContinueButton).click()
        );

        Allure.step("UI senkronizasyonu için kısa bekleme (örnek)", () -> {
            // Projede uygun explicit wait varsa bunun yerine onu kullanın.
            Thread.sleep(1000);
        });

        Allure.step("İlk dönüş uçuş kartını seç", () ->
                driver.findElements(firstReturnFlightCard).get(0).click()
        );

        Allure.step("Super Eko paketini seç", () ->
                driver.findElement(superEkoPackage).click()
        );

        Allure.step("Yolcu formu sayfasının göründüğünü doğrula", () ->
                AssertionsHelper.assertElementVisible(driver, passengerForm, 10, "Yolcu Bilgileri Sayfası")
        );

        PassengerFormPage passengerFormPage = Allure.step("Yolcu formu sayfası nesnesini oluştur", () ->
                new PassengerFormPage(driver)
        );

        Allure.step("İletişim bilgilerini doldur (email & telefon)", () ->
                passengerFormPage.fillContactInfo("testuser@gmail.com", "5300000000")
        );

        Allure.step("Yolcu kimlik bilgilerini doldur", () ->
                passengerFormPage.fillPassengerInfo(
                        "Enes",
                        "Aydoğdu",
                        "03",
                        1,           // Mart -> 3
                        "2001",
                        "erkek",
                        "29323306132"
                )
        );

        Allure.step("Ödeme adımına devam et butonuna tıkla", passengerFormPage::clickProceedToPayment);

        Allure.step("Ödeme sayfasının göründüğünü doğrula", () ->
                AssertionsHelper.assertElementVisible(driver, paymentForm, 10, "Ödeme Bilgileri Sayfası")
        );
    }
}
