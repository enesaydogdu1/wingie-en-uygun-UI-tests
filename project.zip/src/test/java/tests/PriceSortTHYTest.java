package tests;

import base.BaseTest;
import io.qameta.allure.*;
import org.testng.annotations.*;
import pages.HomePage;
import pages.ResultsPage;
import utils.AssertionsHelper;
import utils.ConfigReader;

import java.util.List;

@Epic("Flight Search")
@Feature("Price Sorting for Specific Airline")
@Owner("Enes")                 //
public class PriceSortTHYTest extends BaseTest {

    @Severity(SeverityLevel.CRITICAL)
    @Story("Durum 2: THY için fiyat sıralaması ve filtreler")
    @Description("THY filtrele, 10:00–18:00 zaman aralığı, fiyata göre artan sıralama ve sonuçların doğrulanması")
    @Test(description = "THY filtrele, 10:00–18:00, fiyata göre artan sırala ve doğrula")
    @Parameters({"baseUrl"})
    public void priceSortForTHY(@Optional String baseUrl) {
        String url = baseUrl != null ? baseUrl : ConfigReader.get("baseUrl");

        new HomePage(driver, explicitWaitSec)
                .goTo(url)
                .ensureRoundTrip()
                .setFrom("İstanbul")
                .setTo("Ankara")
                .setDates(ConfigReader.get("departDate"), ConfigReader.get("returnDate"))
                .search();

        ResultsPage results = new ResultsPage(driver, explicitWaitSec)
                .waitForResults()
                .applyDepartureTimeFilter("10:00", "18:00")
                .filterOnlyTHY()
                .sortByPriceAscending();

        List<Integer> prices   = results.getAllPrices();
        List<String> airlines  = results.getAllAirlines();

        // ---- Doğrulamalar
        Allure.step("Fiyatların artan sırada olduğunu doğrula", () ->
                AssertionsHelper.assertPricesSortedAscending(prices)
        );

        Allure.step(String.format("Tüm uçuşların '%s' olduğunu doğrula", airlines), () ->
                AssertionsHelper.assertAllAirlinesAreTHY(airlines) //
        );
    }
}
