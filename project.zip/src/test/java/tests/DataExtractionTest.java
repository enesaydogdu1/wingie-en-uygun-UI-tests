package tests;

import base.BaseTest;
import core.AssertUtils;
import io.qameta.allure.*;
import org.testng.annotations.Test;
import pages.HomePage;
import pages.ResultsPage;
import utils.ConfigReader;
import com.opencsv.CSVWriter;

import java.io.FileWriter;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;

@Epic("Analysis & Categorization")
@Feature("Veri Çıkarma ve Analiz için CSV üretimi")
public class DataExtractionTest extends BaseTest {

    @Severity(SeverityLevel.NORMAL)
    @Story("Durum 4: İstanbul - Lefkoşa araması ve CSV export")
    @Test(description = "Tüm uçuşları CSV'ye yaz ve analize hazırla")
    public void extractToCsv() throws Exception {
        String url = ConfigReader.get("baseUrl");
        String from = ConfigReader.get("analysis.route.from");
        String to = ConfigReader.get("analysis.route.to");
        String d1 = ConfigReader.get("analysis.departDate");
        String d2 = ConfigReader.get("analysis.returnDate");
        String exportDir = ConfigReader.get("analysis.exportDir");

        new HomePage(driver, explicitWaitSec)
                .goTo(url)
                .ensureRoundTrip()
                .ensureHotelsListUnchecked()
                .setFrom(from)
                .setTo(to)
                .setDates(d1, d2)
                .search();

        ResultsPage results = new ResultsPage(driver, explicitWaitSec).waitForResults();

        List<String[]> rows = results.extractFlightRows();
        AssertUtils.mustTrue(!rows.isEmpty(), "Hiç satır toplanamadı");

        Path dir = Path.of(exportDir);
        Files.createDirectories(dir);
        String out = dir.resolve("flights_" + from + "_" + to + ".csv").toString();

        try (CSVWriter writer = new CSVWriter(new FileWriter(out))) {
            writer.writeNext(new String[]{"departure_time","arrival_time","airline","price","duration","stops"});
            for (String[] r : rows) writer.writeNext(r);
        }
    }
}
