package utils;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import java.text.Normalizer;
import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeFormatterBuilder;
import java.time.temporal.ChronoField;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;

public class AssertionsHelper {

    private static final Logger log = LogManager.getLogger(AssertionsHelper.class);

    public static void assertTimesWithinRange(List<String> actualTimes, String expectedFrom, String expectedTo) {
        DateTimeFormatter fmt = DateTimeFormatter.ofPattern("HH:mm");
        LocalTime from = LocalTime.parse(expectedFrom, fmt);
        LocalTime to   = LocalTime.parse(expectedTo, fmt);

        List<String> outOfRangeTimes = new ArrayList<>();

        for (String timeStr : actualTimes) {
            if (timeStr == null || timeStr.isBlank()) continue;

            String clean = timeStr.trim();
            if (clean.length() > 5) clean = clean.substring(0, 5);

            LocalTime actual = LocalTime.parse(clean, fmt);
            boolean inRange = !actual.isBefore(from) && !actual.isAfter(to);

            if (!inRange) {
                outOfRangeTimes.add(clean);
            }
        }

        if (outOfRangeTimes.isEmpty()) {
            log.info("Listelenen tüm uçuşların kalkış saatleri {} - {} aralığında. (Toplam {} uçuş)", expectedFrom, expectedTo, actualTimes.size());
        } else {
            log.error("{} adet kalkış saati aralık dışında: {}", outOfRangeTimes.size(), outOfRangeTimes);
            Assert.fail(String.format("Filtre dışında saatler bulundu: %s", outOfRangeTimes));
        }
    }

    public static void assertDatesEqual(List<String> actualDates, String expectedDate) {
        DateTimeFormatter expectedFmt = DateTimeFormatter.ofPattern("yyyy-MM-dd", Locale.US);
        LocalDate expected = LocalDate.parse(expectedDate, expectedFmt);
        int expectedYear = expected.getYear();

        Locale tr = new Locale("tr", "TR");

        // Yıl içeren formatlar
        DateTimeFormatter withYearShort = DateTimeFormatter.ofPattern("d MMM yyyy", tr);   // 13 Kas 2025
        DateTimeFormatter withYearLong  = DateTimeFormatter.ofPattern("d MMMM yyyy", tr);  // 13 Kasım 2025

        // Yıl OLMAYAN formatlar -> expectedYear ile tamamla
        DateTimeFormatter noYearShort = new DateTimeFormatterBuilder()
                .parseCaseInsensitive()
                .appendPattern("d MMM")               // 13 Kas
                .parseDefaulting(ChronoField.YEAR, expectedYear)
                .toFormatter(tr);

        DateTimeFormatter noYearLong = new DateTimeFormatterBuilder()
                .parseCaseInsensitive()
                .appendPattern("d MMMM")              // 13 Kasım
                .parseDefaulting(ChronoField.YEAR, expectedYear)
                .toFormatter(tr);

        List<String> mismatched = new ArrayList<>();

        for (String raw : actualDates) {
            if (raw == null) continue;

            // Temizlik: tireler ve gün adları (Perşembe vs.) uçabilir, çift boşlukları sık.
            String s = raw.replace(" -", " ")
                    .replace("-", " ")
                    .replaceAll("(?iu)\\b(pazartesi|salı|çarşamba|perşembe|cuma|cumartesi|pazar)\\b", "")
                    .trim()
                    .replaceAll("\\s+", " ");

            LocalDate parsed = null;

            // 1) yıl içeren formatları dene
            for (DateTimeFormatter f : new DateTimeFormatter[]{withYearShort, withYearLong}) {
                try { parsed = LocalDate.parse(s, f); break; } catch (Exception ignore) {}
            }
            // 2) yıl olmayan formatları dene (expectedYear ile tamamla)
            if (parsed == null) {
                for (DateTimeFormatter f : new DateTimeFormatter[]{noYearShort, noYearLong}) {
                    try { parsed = LocalDate.parse(s, f); break; } catch (Exception ignore) {}
                }
            }

            if (parsed == null) {
                mismatched.add(s + " (parse edilemedi)");
            } else if (!parsed.equals(expected)) {
                mismatched.add(s);
            }
        }

        if (mismatched.isEmpty()) {
            log.info("Tüm kalkış tarihleri beklenen tarih ile aynı: {}", expectedDate);
        } else {
            log.error("{} adet kalkış tarihi beklenenle uyuşmuyor. Beklenen: {}, Uyuşmayanlar: {}",
                    mismatched.size(), expectedDate, mismatched);
            Assert.fail("Tarih uyuşmazlıkları bulundu: " + mismatched);
        }
    }

    public static void assertCitiesEqual(List<String> actualCities, String expectedCity) {
        Locale tr = new Locale("tr", "TR");
        String expectedNorm = normalizeCity(expectedCity, tr);

        List<String> mismatched = new ArrayList<>();

        for (int i = 0; i < actualCities.size(); i++) {
            String raw = actualCities.get(i);
            if (raw == null || raw.isBlank()) {
                mismatched.add("#" + (i + 1) + ": (boş/null)");
                continue;
            }

            String actualNorm = normalizeCity(raw, tr);

            if (!actualNorm.equals(expectedNorm)) {
                mismatched.add("#" + (i + 1) + ": '" + raw + "'");
            }
        }

        if (mismatched.isEmpty()) {
            log.info("Tüm kalkış şehirleri beklenen şehir ile aynı: {}", expectedCity);
        } else {
            log.error("{} kartta kalkış şehri beklenenden farklı. Beklenen: {}, Uyuşmayanlar: {}",
                    mismatched.size(), expectedCity, mismatched);
            Assert.fail("Şehir uyuşmazlıkları bulundu: " + mismatched);
        }
    }

    private static String normalizeCity(String s, Locale tr) {
        // 1) virgülün solundaki kısmı al
        String left = s.split(",")[0].trim();

        // 2) unicode normalize (aksanları sil)
        String nfd = Normalizer.normalize(left, Normalizer.Form.NFD)
                .replaceAll("\\p{M}+", ""); // diacritics

        // 3) TR locale ile lower; “İ/ı” özel durumlarını kapsar
        String lowered = nfd.toLowerCase(tr).replaceAll("\\s+", " ").trim();

        // 4) bazı sitelerde “i̇” (i + combining dot) kalabiliyor; güvenlik için sadeleştir
        lowered = lowered.replace("i̇", "i");

        return lowered;
    }

    /** Fiyatların artan sırada (non-decreasing) olduğunu doğrular. */
    public static void assertPricesSortedAscending(List<Integer> prices) {
        if (prices == null || prices.isEmpty()) {
            log.error("Fiyat listesi boş.");
            Assert.fail("Fiyat listesi boş.");
        }

        List<Integer> mismatches = new ArrayList<>();
        for (int i = 1; i < prices.size(); i++) {
            Integer prev = prices.get(i - 1);
            Integer cur  = prices.get(i);
            if (cur < prev) {
                mismatches.add(i); // bozuk index
            }
        }

        if (mismatches.isEmpty()) {
            log.info("Fiyatların artan sırada olduğu doğrulandı. Toplam fiyat sayısı={})", prices.size());
        } else {
            // debug’a yardımcı olsun diye beklenenle kıyas
            List<Integer> sorted = new ArrayList<>(prices);
            sorted.sort(Comparator.naturalOrder());
            log.error("Fiyat sıralaması hatalı. Bozuk indexler: {} \nActual: {}\nSorted: {}",
                    mismatches, prices, sorted);
            Assert.fail("Fiyat sıralaması hatalı. Bozuk indexler: " + mismatches);
        }
    }

    /** Tüm havayolu adlarının THY (Türk Hava Yolları / Turkish Airlines) olduğunu doğrular. */
    public static void assertAllAirlinesAreTHY(List<String> airlines) {
        if (airlines == null || airlines.isEmpty()) {
            log.error("Havayolu listesi boş.");
            Assert.fail("Havayolu listesi boş.");
        }

        List<String> offenders = new ArrayList<>();
        for (int i = 0; i < airlines.size(); i++) {
            String a = airlines.get(i);
            String norm = (a == null ? "" : a).toLowerCase(Locale.ROOT);
            boolean isThy = norm.contains("türk hava yolları") || norm.contains("turkish airlines") || norm.contains("thy");
            if (!isThy) offenders.add("#" + (i + 1) + ": '" + a + "'");
        }

        if (offenders.isEmpty()) {
            log.info("Görüntülenen tüm uçuşlar THY.");
        } else {
            log.error("THY dışı havayolları bulundu: {}", offenders);
            Assert.fail("THY dışı havayolları bulundu: " + offenders);
        }
    }


    /** Verilen locator'ın belirtilen süre içinde GÖRÜNÜR olmasını doğrular. */
    public static void assertElementVisible(WebDriver driver, By locator, int timeoutSeconds, String desc) {
        try {
            new WebDriverWait(driver, Duration.ofSeconds(timeoutSeconds))
                    .until(ExpectedConditions.visibilityOfElementLocated(locator));
            log.info("{} yüklendi ve görünür: {}", desc, locator);
        } catch (Exception e) {
            log.error("{} yüklenemedi veya görünür değil: {}", desc, locator, e);
            Assert.fail(desc + " yüklenemedi veya görünür değil: " + locator);
        }
    }





}
