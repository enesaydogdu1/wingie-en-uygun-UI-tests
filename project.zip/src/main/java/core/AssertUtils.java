package core;

import org.testng.Assert;
import org.testng.asserts.SoftAssert;


public class AssertUtils {
    private final SoftAssert soft = new SoftAssert();

    public void softTrue(boolean condition, String message) {
        soft.assertTrue(condition, message);
    }

    public void softEquals(Object actual, Object expected, String message) {
        soft.assertEquals(actual, expected, message);
    }

    public void assertAll() {
        soft.assertAll();
    }

    public static void mustTrue(boolean condition, String message) {
        Assert.assertTrue(condition, message);
    }
}
