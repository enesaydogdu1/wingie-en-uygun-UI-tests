package base;

import io.qameta.allure.Allure;
import io.qameta.allure.Attachment;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import utils.ConfigReader;
import utils.DriverFactory;

import java.nio.charset.StandardCharsets;

public abstract class BaseTest {
    protected WebDriver driver;
    protected long explicitWaitSec;
    protected final Logger log = LogManager.getLogger(this.getClass());

    @BeforeMethod(alwaysRun = true)
    @Parameters({"browser"})
    public void setUp(@Optional String browserParam) {
        if (browserParam != null) System.setProperty("browser", browserParam);
        explicitWaitSec = Long.parseLong(ConfigReader.get("explicitWait"));
        DriverFactory.initDriver();
        driver = DriverFactory.getDriver();
        log.info("Driver başlatıldı. Browser={}", ConfigReader.get("browser"));
    }

    @AfterMethod(alwaysRun = true)
    public void tearDown() {
        DriverFactory.quitDriver();
        log.info("Driver kapatıldı");
    }

    // ===== Allure attachment'ları (isteğe bağlı) =====
    @Attachment(value = "Screenshot", type = "image/png")
    private byte[] attachScreenshot() {
        try { return ((TakesScreenshot) driver).getScreenshotAs(OutputType.BYTES); }
        catch (Exception ignored) { return new byte[0]; }
    }

    @Attachment(value = "Page Source", type = "text/html", fileExtension = ".html")
    private byte[] attachPageSource() {
        try { return driver.getPageSource().getBytes(StandardCharsets.UTF_8); }
        catch (Exception ignored) { return "<empty/>".getBytes(StandardCharsets.UTF_8); }
    }

    // FAIL olduğunda otomatik ekler; BaseTest’te zaten varsa oraya koy
    @AfterMethod(alwaysRun = true)
    public void afterEach(ITestResult result) {
        if (!result.isSuccess()) {
            Allure.step("Test failed — attaching screenshot & page source", () -> {
                attachScreenshot();
                attachPageSource();
            });
        }
    }
}
