package pages;

import base.BasePage;
import io.qameta.allure.Step;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;

import java.util.ArrayList;
import java.util.List;

public class ResultsPage extends BasePage {

    // ===== Helper: kart ve içindeki lokatörleri index’e göre üret =====
    private By cardByIndex(int i) {
        return By.xpath("(//div[contains(@class,'flight-item')])[" + (i + 1) + "]");
    }

    private By detayBtnInCardByIndex(int i) {
        return By.xpath("(//div[contains(@class,'flight-item')])[" + (i + 1) + "]//button[contains(., 'Detay') or contains(.,'Detail')]");
    }

    private By originInCardByIndex(int i) {
        return By.xpath("(//div[contains(@class,'flight-item')])[" + (i + 1) + "]//div[contains(@class,'segment-airport-origin')]");
    }

    private By timeInCardByIndex(int i) {
        return By.xpath("(//div[contains(@class,'flight-item')])[" + (i + 1) + "]//div[contains(@class,'segment-airport-origin')]//span[@data-testid='undefinedTime']");
    }

    private By dateInCardByIndex(int i) {
        return By.xpath("(//div[contains(@class,'flight-item')])[" + (i + 1) + "]//div[contains(@class,'segment-airport-origin')]//span[@data-testid='undefinedDate']");
    }

    private By airportInfoInCardByIndex(int i) {
        return By.xpath("(//div[contains(@class,'flight-item')])[" + (i + 1) + "]//div[contains(@class,'segment-airport-origin')]//span[@data-testid='undefinedFlightAirportInfo']");
    }

    private final By resultsContainer = By.cssSelector("div.search-result.search-result-departure-only");
    private final By anyResultItem = By.cssSelector("div.flight-item");

    private final By loaderCircle = By.cssSelector("#lotie-animation .spinner-layer .circle");

    private final By summaryRoute = By.cssSelector("div.info strong.graphic-strong");

    private final By departureTimeFilterOpen = By.cssSelector("div.ctx-filter-departure-return-time.card-header");
    private final By leftHandle = By.cssSelector(".rc-slider-handle.rc-slider-handle-1"); // kalkış
    private final By rightHandle = By.cssSelector(".rc-slider-handle.rc-slider-handle-2"); // varış
    private final By sliderContainer = By.cssSelector(".rc-slider"); // parent; rail genişliğini buradan alacağız


    private final By eachDepartureTimeText = By.cssSelector("[data-testid='departure-time'], .flight-card .time .depart");
    private final By eachAirlineText = By.cssSelector("[data-testid='airline-name'], .flight-card .carrier-name");
    private final By eachPriceText = By.cssSelector("[data-testid='price'], .flight-card .price");

    private final By originBlock = By.cssSelector(".segment-airports .segment-airport-origin");
    private final By timeSpan = By.cssSelector("[data-testid='undefinedTime']");
    private final By dateSpan = By.cssSelector("[data-testid='undefinedDate']");
    private final By airportInfoSpan = By.cssSelector("[data-testid='undefinedFlightAirportInfo']");
    private final By detayBtnInCard = By.xpath(".//button[contains(., 'Detay') or contains(., 'Detail')]"); // TR/EN güvenli
    private final By airlinesDropdown = By.cssSelector("div.ctx-filter-airline.card-header");

    private final By thyFilterCheckbox = By.xpath("//label[contains(@for,'TK') and contains(.,'Türk Hava Yolları')]");
    private final By sortByPriceAsc = By.cssSelector("div.sort-buttons.search__filter_sort-PRICE_ASC");


    public ResultsPage(WebDriver driver, long explicitWaitSec) {
        super(driver, explicitWaitSec);
    }


    private void openDepartureTimeSectionIfCollapsed() {
        WebElement header = wait.until(ExpectedConditions.elementToBeClickable(departureTimeFilterOpen));
        // çoğu UI'da toggle; güvenli şekilde tıkla (bir kere)
        header.click();
    }

    private int parseHHmmToMinutes(String hhmm) {
        String[] parts = hhmm.trim().split(":");
        if (parts.length != 2) throw new IllegalArgumentException("Saat formatı HH:mm olmalı. Örn: 10:00");
        int h = Integer.parseInt(parts[0]);
        int m = Integer.parseInt(parts[1]);
        if (h < 0 || h > 23 || m < 0 || m > 59)
            throw new IllegalArgumentException("Saat 00:00–23:59 aralığında olmalı");
        return h * 60 + m; // 0–1439
    }

    private void moveHandleToMinutes(WebElement container, WebElement handle, int targetMinutes) {
        // 1) Container boyutu ve sol x
        int containerWidth = container.getSize().getWidth();
        int containerX = container.getLocation().getX();

        // 2) Mevcut konum (yüzdeyi style'dan, yoksa aria-valuenow'dan tahmin et)
        double currentPercent = readHandleLeftPercent(handle);
        if (Double.isNaN(currentPercent)) {
            // fallback: aria-valuenow (0–1439) -> %
            String nowAttr = handle.getAttribute("aria-valuenow");
            if (nowAttr != null && nowAttr.matches("\\d+")) {
                int nowMin = Integer.parseInt(nowAttr);
                currentPercent = (nowMin / 1439.0) * 100.0;
            } else {
                // son çare: handle & container X farkı
                int handleCenterX = handle.getLocation().getX() - containerX;
                currentPercent = (handleCenterX * 100.0) / containerWidth;
            }
        }

        double targetPercent = (targetMinutes / 1439.0) * 100.0;

        // 3) Piksel cinsinden delta
        int deltaX = (int) Math.round((targetPercent - currentPercent) * containerWidth / 100.0);

        // 4) Sürükleme
        Actions actions = new Actions(driver);
        actions.clickAndHold(handle)
                .moveByOffset(deltaX, 0)
                .release()
                .perform();

        // ufak stabilizasyon
        try {
            Thread.sleep(150);
        } catch (InterruptedException ignored) {
        }
    }


    @Step("Sonuçları bekle")
    public ResultsPage waitForResults() {
        // 1) Arama sayfasına geçişi bekle (URL)
        try {
            wait.until(ExpectedConditions.urlContains("/ucak-bileti/arama"));
        } catch (Exception ignored) {
        }

        // 2) Container DOM’a gelsin (visibility yerine presence)
        wait.until(ExpectedConditions.presenceOfElementLocated(resultsContainer));

        // 3) Kartların gelmesini döngüyle bekle (en sağlamı)
        long end = System.currentTimeMillis() + 20000; // 20 sn üst sınır
        List<WebElement> cards = new ArrayList<>();
        while (System.currentTimeMillis() < end) {
            cards = driver.findElements(anyResultItem);
            if (cards != null && !cards.isEmpty()) break;
            shortWait(0.3);
        }
        if (cards == null || cards.isEmpty()) {
            throw new TimeoutException("Uçuş kartları yüklenmedi (anyResultItem).");
        }

        // 4) İlk kart görünür olana kadar ufak bekleme (scroll ihtimali vs.)
        try {
            WebElement first = cards.get(0);
            ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView({block:'center'});", first);
            wait.until(ExpectedConditions.visibilityOf(first));
        } catch (Exception ignored) {
        }

        log.info("Uçuş sonuçları yüklendi. Toplam uçuş sayısı: {}", cards.size());
        return this;
    }

    @Step("Kalkış saati filtresi: {from}-{to}")
    public ResultsPage applyDepartureTimeFilter(String fromHHmm, String toHHmm) {

        openDepartureTimeSectionIfCollapsed();

        int fromMin = parseHHmmToMinutes(fromHHmm);  // 10:00 -> 600
        int toMin = parseHHmmToMinutes(toHHmm);    // 18:00 -> 1080

        WebElement container = wait.until(ExpectedConditions.visibilityOfElementLocated(sliderContainer));
        WebElement left = wait.until(ExpectedConditions.visibilityOfElementLocated(leftHandle));
        WebElement right = wait.until(ExpectedConditions.visibilityOfElementLocated(rightHandle));

        // Sol ve sağ handle'ları hedef dakikalara sürükle
        moveHandleToMinutes(container, left, fromMin);
        // wait.until(ExpectedConditions.invisibilityOfElementLocated(loaderCircle));
        shortWait(1);
        moveHandleToMinutes(container, right, toMin);

        // Doğrulama
        wait.until(d -> String.valueOf(fromMin).equals(left.getAttribute("aria-valuenow")));
        wait.until(d -> String.valueOf(toMin).equals(right.getAttribute("aria-valuenow")));
        log.info("Kalkış saati filtresi uygulandı: {} - {}", fromHHmm, toHHmm);
        return this;
    }


    private double readHandleLeftPercent(WebElement handle) {
        try {
            String style = handle.getAttribute("style"); // örn: "left: 41.6956%;"
            if (style == null) return Double.NaN;
            for (String part : style.split(";")) {
                String s = part.trim();
                if (s.startsWith("left:")) {
                    String v = s.replace("left:", "").replace("%", "").trim();
                    return Double.parseDouble(v);
                }
            }
            return Double.NaN;
        } catch (Exception e) {
            return Double.NaN;
        }
    }

    @Step("Havayolu filtresi: Türk Hava Yolları")
    public ResultsPage filterOnlyTHY() {
        try {
            click(airlinesDropdown);
            shortWait(0.5);
            click(thyFilterCheckbox);
            log.info("Türk Hava Yolları'na ait uçuşlar filtrelendi.");
        } catch (Exception ignored) {
        }
        return this;
    }

    @Step("Fiyata göre artan sırala")
    public ResultsPage sortByPriceAscending() {
        try {
            click(sortByPriceAsc);
            log.info("Fiyat artandan azalana göre seçildi.");
        } catch (Exception ignored) {
        }
        return this;
    }

    @Step("Saat aralığını doğrula: {from}-{to}")
    public boolean verifyAllDepartureTimesBetween(String from, String to) {
        java.time.LocalTime min = java.time.LocalTime.parse(from);
        java.time.LocalTime max = java.time.LocalTime.parse(to);
        List<WebElement> times = driver.findElements(eachDepartureTimeText);
        if (times.isEmpty()) return false;
        for (WebElement t : times) {
            String txt = t.getText().trim();
            if (txt.length() < 5) return false;
            String hhmm = txt.substring(0, 5);
            java.time.LocalTime actual;
            try {
                actual = java.time.LocalTime.parse(hhmm);
            } catch (Exception e) {
                return false;
            }
            if (actual.isBefore(min) || actual.isAfter(max)) return false;
        }
        return true;
    }

    @Step("Liste görünürlüğü")
    public boolean isListVisible() {
        try {
            return driver.findElement(resultsContainer).isDisplayed();
        } catch (NoSuchElementException e) {
            return false;
        }
    }


    @Step("Tüm kartların havayolu isimlerini al")
    public List<String> getAllAirlines() {
        List<String> out = new ArrayList<>();
        List<WebElement> elements = driver.findElements(
                By.cssSelector("div.summary-marketing-airlines[data-testid]")
        );

        for (WebElement el : elements) {
            String name = el.getText().trim();
            if (!name.isEmpty()) out.add(name);
        }

        log.info("✈️ {} adet havayolu ismi alındı: {}", out.size(), out.get(0));
        return out;
    }

    @Step("Tüm kartların fiyatlarını (sayısal) al")
    public List<Integer> getAllPrices() {
        List<Integer> prices = new ArrayList<>();

        // fiyat elementlerini bul
        List<WebElement> elements = driver.findElements(
                By.cssSelector("div.summary-average-price span.money-int")
        );

        for (WebElement el : elements) {
            String raw = el.getText().replaceAll("[^0-9]", "").trim();
            if (!raw.isEmpty()) {
                try {
                    prices.add(Integer.parseInt(raw));
                } catch (NumberFormatException e) {
                    log.warn("Sayısal parse hatası: '{}'", raw);
                }
            }
        }

        log.info("{} adet fiyat çekildi: {}", prices.size(), prices);
        return prices;
    }


    @Step("Uçuş kartlarından veri çıkar (Case 4)")
    public List<String[]> extractFlightRows() {
        List<WebElement> cards = driver.findElements(anyResultItem);
        List<String[]> rows = new ArrayList<>();
        for (WebElement card : cards) {
            String dep = getTextSafe(card, "[data-testid='departure-time'], .time .depart");
            String arr = getTextSafe(card, "[data-testid='arrival-time'], .time .arrive");
            String airline = getTextSafe(card, "[data-testid='airline-name'], .carrier-name");
            String price = getTextSafe(card, "[data-testid='price'], .price");
            String duration = getTextSafe(card, "[data-testid='duration'], .duration");
            String stops = getTextSafe(card, "[data-testid='stops'], .stops");
            rows.add(new String[]{dep, arr, airline, price, duration, stops});
        }
        return rows;
    }

    private String getTextSafe(WebElement context, String css) {
        try {
            return context.findElement(By.cssSelector(css)).getText().trim();
        } catch (Exception e) {
            return "";
        }
    }


    // Listeyi her seferinde güncel olarak çek.
    private int getCardsCount() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(resultsContainer));
        return driver.findElements(anyResultItem).size();
    }

    // Detayı güvenli aç (index bazlı, stale’a dayanıklı)
    private void openDetailsIfNeeded(int i) {
        int retries = 2;
        for (int attempt = 0; attempt <= retries; attempt++) {
            try {
                // Origin zaten görünür mü?
                List<WebElement> origins = driver.findElements(originInCardByIndex(i));
                if (!origins.isEmpty() && origins.get(0).isDisplayed()) return;

                WebElement btn = driver.findElement(detayBtnInCardByIndex(i));
                ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView({block:'center'});", btn);
                btn.click();

                // Tık sonrası yeniden locate + refreshed bekle
                wait.until(ExpectedConditions.refreshed(
                        ExpectedConditions.visibilityOfElementLocated(originInCardByIndex(i))
                ));
                return;
            } catch (StaleElementReferenceException | ElementClickInterceptedException e) {
                if (attempt == retries) throw e; // son deneme de patlarsa yukarı fırlat
                // minik bekleme, sonra tekrar dene
                try {
                    Thread.sleep(250);
                } catch (InterruptedException ignored) {
                }
            }
        }
    }

    // ===== İSTEDİĞİN GETTER: sadece filtre sonrası taze listedeki kartları işler =====
    public List<String> karttakiKalkisSaatleriniGetir() {
        int n = getCardsCount();
        List<String> out = new ArrayList<>(n);
        for (int i = 0; i < n; i++) {
            openDetailsIfNeeded(i); // stale-safe
            // her defasında yeniden locate et
            String t = wait.until(ExpectedConditions.visibilityOfElementLocated(timeInCardByIndex(i)))
                    .getText().replace(" -", "").trim();
            out.add(t);
        }
        return out;
    }

    public List<String> karttakiKalkisTarihlereniGetir() {
        int n = getCardsCount();
        List<String> out = new ArrayList<>(n);
        for (int i = 0; i < n; i++) {
            openDetailsIfNeeded(i);
            String d = wait.until(ExpectedConditions.visibilityOfElementLocated(dateInCardByIndex(i)))
                    .getText().replace(" -", "").trim();
            out.add(d);
        }
        return out;
    }

    public List<String> karttakiKalkisSehirleriniGetir() {
        int n = getCardsCount();
        List<String> out = new ArrayList<>(n);
        for (int i = 0; i < n; i++) {
            openDetailsIfNeeded(i);
            String info = wait.until(ExpectedConditions.visibilityOfElementLocated(airportInfoInCardByIndex(i)))
                    .getText().trim();
            out.add(info.split(",")[0].trim());
        }
        return out;
    }

    // === Yardımcılar ===
    private List<WebElement> getCards() {
        WebElement container = wait.until(ExpectedConditions.visibilityOfElementLocated(resultsContainer));
        return container.findElements(anyResultItem);
    }

    /**
     * Detay kapalıysa açar, açık ise dokunmaz; idempotent
     */
    private WebElement ensureDetailsOpen(WebElement card) {
        try {
            WebElement origin = card.findElement(originBlock);
            if (origin.isDisplayed()) return card;
        } catch (NoSuchElementException ignored) {
        }

        try {
            WebElement detay = card.findElement(detayBtnInCard);
            if (detay.isDisplayed()) {
                ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView({block:'center'});", detay);
                detay.click();
                wait.until(ExpectedConditions.visibilityOf(card.findElement(originBlock)));
            }
        } catch (NoSuchElementException ignored) {
        }
        return card;
    }

    // (İstersen) tek seferde toplu veri döndüren POJO
    public List<FlightCardInfo> getAllCardsInfo() {
        List<WebElement> cards = getCards().stream().map(this::ensureDetailsOpen).toList();
        List<FlightCardInfo> out = new ArrayList<>();
        for (WebElement c : cards) {
            String time = c.findElement(originBlock).findElement(timeSpan).getText().replace(" -", "").trim();
            String date = c.findElement(originBlock).findElement(dateSpan).getText().replace(" -", "").trim();
            String ainfo = c.findElement(originBlock).findElement(airportInfoSpan).getText().trim();
            String city = ainfo.split(",")[0].trim();
            out.add(new FlightCardInfo(time, date, city));
        }
        return out;
    }

    public static record FlightCardInfo(String departureTime, String departureDate, String departureCity) {
    }

}
