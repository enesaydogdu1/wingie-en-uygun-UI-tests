package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

public class PassengerFormPage {

    private WebDriver driver;

    public PassengerFormPage(WebDriver driver) {
        this.driver = driver;
    }

    // ---- Root / critical elements ----
    private final By root = By.id("passenger-form");
    private final By submitBtn = By.xpath("//*[@id=\"continue-button\"]");

    // ---- Contact info ----
    private final By emailInput = By.cssSelector(
            "#passenger-form input[name='email'], #passenger-form input[type='email']");
    private final By phoneInput = By.cssSelector(
            "#passenger-form input[name='phone'], #passenger-form input[type='tel']");

    // ---- Passenger basic fields ----
    private final By firstNameInput = By.xpath("//*[@id='firstName_0']");
    private final By lastNameInput = By.xpath("//*[@id='lastName_0']");

    private final By dobDayInput = By.xpath("//*[@id='birthDateDay_0']");
    private final By dobMonthInput = By.xpath("//*[@id='birthDateMonth_0']");
    private final By dobYearInput = By.xpath("//*[@id='birthDateYear_0']");

    private final By maleGenderLabel   = By.cssSelector("label[for='gender_M_0']");
    private final By femaleGenderLabel = By.cssSelector("label[for='gender_F_0']");


    private final By nationalIdInput = By.cssSelector("input[data-testid='reservation-publicid-TR-input']");
    private final By rightSummaryBox = By.cssSelector("div.col-md-4, aside, div.trip-summary, div#trip-summary");

    // ---- Actions ----

    public void fillContactInfo(String email, String phone) {
        driver.findElement(emailInput).sendKeys(email);
        driver.findElement(phoneInput).sendKeys(phone);
    }

    public void fillPassengerInfo(String firstName,
                                  String lastName,
                                  String day,
                                  int monthIndex,   // 👈 ayı index olarak alacağız (1=Ocak, 2=Şubat, 3=Mart...)
                                  String year,
                                  String gender,
                                  String nationalId) {

        driver.findElement(firstNameInput).sendKeys(firstName);
        driver.findElement(lastNameInput).sendKeys(lastName);

        // --- Doğum tarihi ---
        WebElement dayField = driver.findElement(dobDayInput);
        dayField.sendKeys(day);
        dayField.sendKeys(Keys.TAB);

        // Ay alanı genelde <select> olduğu için index ile seçiyoruz
        WebElement monthElement = driver.findElement(dobMonthInput);
        Select selectMonth = new Select(monthElement);
        selectMonth.selectByIndex(monthIndex); // 1=Ocak, 3=Mart vb.

        WebElement yearField = driver.findElement(dobYearInput);
        yearField.sendKeys(year);
        yearField.sendKeys(Keys.ENTER);

        // --- Cinsiyet seçimi ---
        if (gender.equalsIgnoreCase("erkek")) {
            driver.findElement(maleGenderLabel).click();
        } else if (gender.equalsIgnoreCase("kadın")) {
            driver.findElement(femaleGenderLabel).click();
        }

        // --- TC Kimlik ---
        driver.findElement(nationalIdInput).sendKeys(nationalId);
    }

    public void clickProceedToPayment() {
        driver.findElement(submitBtn).click();
    }
}
