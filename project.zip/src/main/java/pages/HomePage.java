package pages;

import base.BasePage;
import io.qameta.allure.Step;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;

public class HomePage extends BasePage {


    private final By fromInput = By.cssSelector("input[placeholder*='Nereden'], input[name='origin']");
    private final By toInput = By.cssSelector("input[placeholder*='Nereye'], input[name='destination']");
    private final By departDateInput = By.cssSelector("[data-testid='enuygun-homepage-flight-departureDate-datepicker-input']");
    private final By returnDateInput = By.cssSelector("[data-testid='enuygun-homepage-flight-returnDate-datepicker-input']");
    private final By searchButton = By.cssSelector("button[data-testid='enuygun-homepage-flight-submitButton']");
    private final By roundTripToggle = By.xpath("//label[normalize-space()='Gidiş-dönüş']");
    private final By listHotelsCheckbox = By.cssSelector("input[data-testid='flight-oneWayCheckbox-input']");



    public HomePage(WebDriver driver, long explicitWaitSec) { super(driver, explicitWaitSec); }

    @Step("Anasayfa: {baseUrl}")
    public HomePage goTo(String baseUrl) { driver.get(baseUrl); acceptCookiesIfPresent(); return this; }

    @Step("Gidiş-dönüş modu")
    public HomePage ensureRoundTrip() { try { click(roundTripToggle); } catch (Exception ignored) {} return this; }

    @Step("Nereden: {from}")
    public HomePage setFrom(String from) { type(fromInput, from); pressEnter(fromInput); return this; }

    @Step("Nereye: {to}")
    public HomePage setTo(String to) { type(toInput, to); pressEnter(toInput); return this; }

    @Step("Tarih seçimi: {depart} → {ret}")
    public HomePage setDates(String depart, String ret) {


        // 🟢 Gidiş tarihi seçimi
        click(departDateInput);
        shortWait(0.2);
        selectDateFromCalendar(depart, "Gidiş");

        // 🟢 Dönüş tarihi seçimi
        click(returnDateInput);
        shortWait(0.2);
        selectDateFromCalendar(ret, "Dönüş");

        return this;
    }

    private void selectDateFromCalendar(String date, String type) {
        // Beklenen format: "2025-10-29"
        String locator = String.format("//button[@title='%s']", date);
        By dayButton = By.xpath(locator);

        try {
            wait.until(ExpectedConditions.elementToBeClickable(dayButton));
            WebElement element = driver.findElement(dayButton);
            element.click();
            log.info("{} tarihi seçildi: {}", type, date);
        } catch (Exception e) {
            log.error("{} tarihi seçimi başarısız oldu: {} - {}", type, date, e.getMessage());
            throw e;
        }
    }

    @Step("Otelleri listeleme kutusunu kapat (React güvenli)")
    public HomePage ensureHotelsListUnchecked() {
        try {
            WebElement cb = driver.findElement(listHotelsCheckbox);
            boolean selected = cb.isSelected();

            // 1️⃣ İlk durum logu
            log.info("Otel kutusu ilk durumda: {}", selected ? "SEÇİLİ" : "KAPALI");

            // 2️⃣ Gerekirse JS ile kapat
            if (selected) {
                ((org.openqa.selenium.JavascriptExecutor) driver)
                        .executeScript("arguments[0].checked = false; arguments[0].dispatchEvent(new Event('change'));", cb);
                log.info("🟢 JS ile 'Otelleri de listele' kutusu kapatıldı.");
            }

            // 3️⃣ Son kontrol (render gecikmesi varsa 0.3 sn bekle)
            shortWait(0.3);
            boolean nowSelected = driver.findElement(listHotelsCheckbox).isSelected();
            log.info("Son durumda: {}", nowSelected ? "HALA SEÇİLİ ❌" : "KAPALI ✅");

        } catch (Exception e) {
            log.warn("⚠️ Otel listeleme kutusu bulunamadı veya değiştirilemedi: {}", e.getMessage());
        }
        return this;
    }


    @Step("Ara")
    public void search() {
        click(searchButton); }
}
